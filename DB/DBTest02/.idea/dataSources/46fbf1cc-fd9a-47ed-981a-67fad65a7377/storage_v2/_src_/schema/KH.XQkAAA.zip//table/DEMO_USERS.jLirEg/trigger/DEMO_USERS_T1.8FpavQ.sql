create trigger DEMO_USERS_T1
    before insert or update
    on DEMO_USERS
    for each row
begin
:NEW.user_name := upper(:NEW.user_name);
end;
/

